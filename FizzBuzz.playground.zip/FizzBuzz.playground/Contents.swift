import UIKit

// FizzBuzz

/*Write a program that prints the numbers from 1 to 100
For numbers divisible by 3, print “Fizz”
For numbers divisible by 5, print “Buzz”
For numbers divisible by both 3 and 5, print “FizzBuzz”*/

let numbers = 1...100

for num in numbers {
    if num % 3 == 0 && num % 5 == 0 {
        print("\(num) FizzBuzz")
    } else if num % 3 == 0 {
        print("\(num) Fizz")
    } else if num % 5 == 0 {
        print("\(num) Buzz")
    } else {
        print(num)
    }
}

